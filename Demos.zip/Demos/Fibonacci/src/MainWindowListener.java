
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainWindowListener implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}


}
