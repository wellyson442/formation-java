import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainWindow extends JFrame{

	private JPanel mainPanel;
	private JButton startButton;
	
	public MainWindow() {
		
		this.startButton = new JButton("Start");
		
	}
}
