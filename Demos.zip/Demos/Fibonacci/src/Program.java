import java.util.concurrent.atomic.AtomicInteger;

public class Program {

	public static void main(String[] args) {
		
		try {
			RecursiveThread rt = new RecursiveThread();
			Thread thread = new Thread(rt);
			//rt.setIsFibo(true);
			thread.start();
			
			System.out.println("Hello");
			Thread.sleep(1000);
			
			System.out.println("Still here");
			Thread.sleep(2000);
			
			System.out.println("Bye Bye");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		//facto
//		int a = 15, result = 1;
//		
//		while(a>1)
//		{
//			result *= a;
//			a--;
//		}
//		
//		System.out.println(result);
			
	}

}
