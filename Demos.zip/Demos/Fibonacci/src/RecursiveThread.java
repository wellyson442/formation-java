import java.util.concurrent.atomic.AtomicBoolean;

public class RecursiveThread implements Runnable {
	
	private AtomicBoolean isFibo = new AtomicBoolean(false);
	
	public void setIsFibo(boolean isFibo){
		this.isFibo.set(isFibo);
	}
	
	@Override
	public void run() {
		
		if(this.isFibo.get())
			System.out.println(fibonacci(40));
		else
			System.out.println(factorial(15));
	}
	
    public static int fibonacci(int n){
    	
    	if (n < 2)
    		return 1;		
    	else 
    		return fibonacci(n-1)+ fibonacci(n-2); 		
    }
    
    public static int factorial (int n){
    	
    	if (n <= 1)
            return 1;
    	else
    		return n*factorial(n-1);
    }
    
    
    
}