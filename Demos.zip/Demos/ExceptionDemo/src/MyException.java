
public class MyException extends Exception{
	
	private static final long serialVersionUID = 4848471462274578988L;
	
	private int errorCode;
	
	public MyException()
	{
		this("Erreur de mon exception");
	}
	
	public MyException(String message)
	{
		this(message, 500);
	}

	public MyException(String message, int errorCode)
	{
		super("erreur : " + message);
		this.errorCode = errorCode;
	}

	public int getErrorCode() {
		return errorCode;
	}
}
