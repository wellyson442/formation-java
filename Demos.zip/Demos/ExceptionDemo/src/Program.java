
public class Program {

	public static void main(String[] args) {
		
		try{
			method();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//System.out.println(e.getMessage());
		}
		
	}
	
	public static void method() throws Exception{
		
		try{
			
			if(true)
				throw new MyException();
		
			//ICI
		}
		catch(MyException e){
			
			System.out.println(e.getMessage());
			
			throw new Exception("erreur", e);
		}
		finally {
			System.out.println("TOUJOURS ICI");
		}
		
		System.out.println("Fin de ma m�thode");
	}

}
