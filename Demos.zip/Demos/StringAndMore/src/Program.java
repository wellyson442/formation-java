import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Program {

	public static void main(String[] args) {
		
//		strConcat();
//		strBuilder();
		
//		strTokenizer();
		
		strRegex();
	}

	private static void strRegex() {
		Pattern p = Pattern.compile("^[a-zA-Z0-9]{2,8}$");
		
		Matcher m = p.matcher("Hello world");
		
		if(m.matches())
			System.out.println("valide");
		else
			System.out.println("invalide");
		
		
		System.out.println("----------");
		
		
		Pattern p2 = Pattern.compile("wo");
		
		Matcher m2 = p2.matcher("Hello world");
		
		if(m2.find())
			System.out.println("trouv�");
		else
			System.out.println("introuvable");
	}

	private static void strTokenizer() {
		StringTokenizer st = new StringTokenizer("Hello Chandler Bing");
		
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());
		
		System.out.println("-----------");
		
		StringTokenizer st2 = new StringTokenizer("Rachel Green;Ross Geller;Joey Tribbiani", ";");
		
		while(st2.hasMoreTokens())
			System.out.println(st2.nextToken());
	}

	private static void strBuilder() {
		
//		String s = "hello";
//		
//		s += "world";
//		s += "bye";
//		s += "test";
//		s += "123";
//		
//		System.out.println(s);
		

		StringBuilder sb = new StringBuilder();
		
		sb.append("Hello");
		sb.append(" world");
		sb.append(" world");
		sb.append(" world");
		
		System.out.println(sb.toString());
	}

	private static void strConcat() {
		char[] chars = {'h', 'e', 'l', 'l', 'o'};
		String s = new String(chars);
		
		System.out.println("nombres de chars : " + s.length()); 
		System.out.println("index de o : " + s.indexOf('o'));
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		
		String s2 = s + " world";
		System.out.println(s2);
		
		String s3 = s.concat(" world");
		System.out.println(s3);
		
		String s4 = String.format("%s %s %s", s, "world", "hello");
		System.out.println(s4);
	}

	
	
}
