package com.people.testdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;

import javax.sql.rowset.CachedRowSet;

import com.sun.rowset.CachedRowSetImpl;


public class Launcher {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/shop";
	    String user = "root";
	    String password = "";
	    
	    Connection db = null;
		
		try {
		    Class.forName( "com.mysql.jdbc.Driver" );
	
		    db = DriverManager.getConnection(url, user, password);
		    
//		    db.setAutoCommit(false);
		    
		    Statement stmt;
		    
//		    stmt = db.createStatement();
//
//		    int status = stmt.executeUpdate( "INSERT INTO person (firstname, lastname, age) "
//		    							   + "VALUES ('Ted', 'Mosby', 35)");
//			stmt.close();

//		    stmt = db.createStatement();
//	    
//		    ResultSet rs = stmt.executeQuery( "SELECT id, firstname, lastname, age FROM person" );
//		    
//		    while (rs.next()) 
//		    {
//		        int id = rs.getInt("id");
//		        String firstname = rs.getString("firstname");
//		        String lastname = rs.getString("lastname");
//		        int age = rs.getInt("age");
//		        
//		        System.out.println(id + " " + firstname + " " + lastname + " " + age + " ans ");
//		    }
//		    
//		    rs.close();
//		    stmt.close();
		    
//		    CachedRowSet rowset = new CachedRowSetImpl();
//		    rowset.populate(rs);
//
//		    rs.close();
//		    stmt.close();
//		    
//			while(rowset.next())
//			{
//				 int id = rowset.getInt("id");
//			     String firstname = rowset.getString("firstname");
//			     String lastname = rowset.getString("lastname");
//			     int age = rowset.getInt("age");
//
//			     System.out.println(id + " " + firstname + " " + lastname + " " + age + " ans ");
//			}
		    
		    
//		    String sql = "UPDATE person SET age = ? WHERE lastname = ?";
//		    
//		    PreparedStatement pStmt = db.prepareStatement(sql);
//		    
//		    pStmt.setInt(1, 30);
//		    pStmt.setString(2, "Mosby");
//		    
//		    pStmt.execute();
//		    
//		    pStmt.close();
		    
//			db.commit();
		    
		} catch ( ClassNotFoundException ex) {
			System.out.println("pb driver");
		} catch (SQLException ex) {
			System.out.println("pb connexion/sql");
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			
//			try {
//				db.rollback();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		}
		finally {
			if ( db != null )
			{
				try {
					db.close();
				} catch ( SQLException ex) {
					System.out.println("pb fermeture de db");
				}
			}
		}
		
		
	}
}
