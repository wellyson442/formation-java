import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Program {

	public static void main(String[] args) {

		//
		// interface
		//
		
		System.out.println("nuit minimum de " + Person.MINIMUM_SLEEPING_HOURS + " heures");

		boolean result1 = Restable.areYouGoodSleeper(8);

		Person pers = new Person();
		boolean result2 = pers.areYouGoodSleeperDefault(8);

		
		
		//
		// inférence de type
		//
		
		
		ArrayList<Person> persons1 = new ArrayList<Person>();
		ArrayList<Person> persons11 = new ArrayList<>();
		var persons111 = new ArrayList<Person>();
		var myInt = 5;
		
		//
		// anonymous class
		//
		
		
		Restable restable = new Restable() {

			@Override
			public void sleep() {

				System.out.println("je dors de façon anonyme");
			}

		};

		restable.sleep();

		
		//
		// lambda 1
		//

		
		// seulement car une methode abstraite
		//(sous entendu @FunctionalInterface)
		Restable restable2 = () -> {
			System.out.println("je dors de façon lambda");
		};

		restable2.sleep();

		
		//
		// lambda 2
		//
		
		
		ArrayList<Person> persons = new ArrayList<Person>();
		persons.add(new Person("Ted", "Mosby", 35));
		persons.add(new Person("Barney", "Stinson", 34));
		persons.add(new Person("Lily", "Aldrin", 32));

		persons.forEach(p -> System.out.println(p.getFirstName()));
		
		//old sort
		Collections.sort(persons, new Comparator<Person>() {
			public int compare(Person p1, Person p2) {
				return p1.getFirstName().compareToIgnoreCase(p2.getFirstName());
			}
		});
		
		//new sort
		Collections.sort(persons, (Person p1, Person p2) -> p1.getFirstName().compareToIgnoreCase(p2.getFirstName()));
		
		Collections.sort(persons, (p1, p2) -> p1.getFirstName().compareToIgnoreCase(p2.getFirstName()));
		
		
		
		
		
		persons.removeIf(p -> p.getAge() == 34);
		
		persons.forEach(p -> System.out.println(p.getFirstName()));
		
		
		//
		// Lambda 3.1
		//
		
		
		List<Person> persons2 = new ArrayList<Person>();
		persons2.add(new Person("Ted", "Mosby", 35));
		persons2.add(new Person("Barney", "Stinson", 34));
		persons2.add(new Person("Lily", "Aldrin", 32));
		
		int result = filterAndSum(persons2, p -> p.getAge() > 30);
		System.out.println(result);
		
		
		//
		// Lambda 3.2
		//
		
		List<Person> persons3 = persons2.stream()
										.filter(p -> p.getAge() > 33)
										.collect(Collectors.toList());
		
		persons3.forEach(p -> System.out.println(p));
		
		
		//
		// reference de méthode CONSUMER
		//
		
		Consumer<Person> consumer = System.out::println;
		persons3.forEach(p -> consumer.accept(p));
		
		
		//plus simple comme ca
		persons3.forEach(System.out::println);
		
		
		//
		// reference de méthode FUNCTION
		//
		
		
		Comparator<Person> comp1 = (p1, p2) -> p1.getAge() - p2.getAge();
		
		Function<Person, Integer> function = Person::getAge;
		Comparator<Person> comp2 = (p1, p2) -> function.apply(p1) - function.apply(p2);
		
		Comparator<Person> comp3 = Comparator.comparing(p -> function.apply(p));
		
		Comparator<Person> comp4 = Comparator.comparing(Person::getAge);
	
		
		//
		// Optional
		//
		
		Optional<Person> option = findByLastName("ted");
		Person p = option.get();
		
		System.out.println(findByLastName("ted"));
	}
	
	public static int filterAndSum(List<Person> persons, Predicate<Person> predicate) {
	    
		return persons.parallelStream()
	    		.filter(predicate)
	    		.mapToInt(p -> p.getAge())
	    		.sum();
		
	}
	
	public static Optional<Person> findByLastName(String lastName) {
	    
		Person person = null;
		
		List<Person> people = new ArrayList<Person>();
		people.add(new Person("Ted", "Mosby", 35));
		people.add(new Person("Barney", "Stinson", 34));
		people.add(new Person("Lily", "Aldrin", 32));
		
		for (Person p : people) {
			
			if(p.getLastName().equalsIgnoreCase(lastName))
			{
				person = p;
				break;
			}
		}
		
	    return Optional.ofNullable(person);
	}
}
