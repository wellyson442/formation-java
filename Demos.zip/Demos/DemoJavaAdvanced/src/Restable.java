
@FunctionalInterface
public interface Restable {

	public void sleep();
	
	public static final int MINIMUM_SLEEPING_HOURS = 6;
	
	public static boolean areYouGoodSleeper(int hoursByDay){
		
		if(hoursByDay > Restable.MINIMUM_SLEEPING_HOURS)
			return true;
		else
			return false;
	}
	
	public default boolean areYouGoodSleeperDefault(int hoursByDay){
		
		if(hoursByDay > Restable.MINIMUM_SLEEPING_HOURS)
			return true;
		else
			return false;
	}
}
