import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class Program {

	public static void main(String[] args) throws Exception {
		
		readBinary();
		readConsole();
		readChars();
		
		writeBinary();
		writePrintBinary();
		writeChars();
		writePrintChars();
		

		
		
		
	}

	private static void writePrintChars() throws FileNotFoundException {
		PrintWriter pw = new PrintWriter("test.txt");
		pw.println("Hello");
		pw.close();
	}

	private static void writeChars() throws IOException {
		FileWriter fw = new FileWriter("test.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write("hello");
		
		bw.close();
		fw.close();
	}

	private static void readChars() throws FileNotFoundException, IOException {
		FileReader fr = new FileReader("test.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String s = br.readLine();
		
		br.close();
		fr.close();
	}

	private static void writePrintBinary() throws FileNotFoundException {
		PrintStream ps = new PrintStream("test.bin");
		ps.println("hello");
		ps.println("world");
		ps.close();
	}

	private static void writeBinary() throws IOException {
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		DataOutputStream dos = null;
		
		try {
			fos = new FileOutputStream("test.bin", true);
			bos = new BufferedOutputStream(fos);
			dos = new DataOutputStream(bos);

			dos.writeChars("hello");
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dos.close();
			bos.close();
			fos.close();
		}
	}

	private static void readConsole() {
		// < 1.5
		BufferedInputStream bis = new BufferedInputStream(System.in);
		DataInputStream dis = new DataInputStream(bis);
		
		//dis.read();
		
		// 1.5
		Scanner scanner = new Scanner(System.in);
		scanner.nextLine();
	}

	private static void readBinary() {
		
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		
		try {
			fis = new FileInputStream("test.bin");
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);
			
			//dis.readUTF()
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			try {
				if(dis != null)
					dis.close();
				
				if(bis != null)
					bis.close();
				
				if(fis != null)
					fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
