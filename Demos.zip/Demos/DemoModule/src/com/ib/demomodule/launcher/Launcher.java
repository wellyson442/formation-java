package com.ib.demomodule.launcher;

import javax.swing.*;

public class Launcher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
