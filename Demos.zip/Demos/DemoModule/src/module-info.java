module com.ib.demomodule.modules {
	
	requires java.desktop;
	
	exports com.ib.demomodule.launcher;
	
}