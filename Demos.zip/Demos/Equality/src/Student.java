
public class Student extends Person {

	private double average = 0.0;

	public Student() {
		super();
	}

	public Student(String firstName, String lastName, int age, double average) {
		super(firstName, lastName, age);
		this.average = average;
	}

	public double getAverage() {
		return average;
	}

	public void setAverage(double average) {
		this.average = average;
	}

	@Override
	public boolean equals(Object object) {
		
		if(!(object instanceof Student))
			return false;
		
		Student student = (Student) object;
		
		if(!super.equals(student))
			return false;
		
		if(!(this.average == student.average))
			return false;
		
		return true;
	}
}
