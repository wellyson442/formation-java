
public class Program {

	public static void main(String[] args) {
		
		Person ted1 = new Person("Ted", "Mosby", 35);
		Person stud = new Person("TED", "Mosby", 35);
		
		if(stud == ted1)
			System.out.println("OUI le meme objet");
		else
			System.out.println("NON pas le meme objet");
		
		
		if(ted1.equals(stud))
			System.out.println("OUI egal");
		else
			System.out.println("NON pas egal");
		
	}

}
