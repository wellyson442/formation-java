import java.io.Serializable;

public class Person implements Comparable<Person>, Serializable {

	private static final long serialVersionUID = 6182647856285413442L;
	
	private String firstName;
	private String lastName;
	private int age;
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}

	public Person() {
		this("Ted", "Mosby", 35);
	}
	
	public Person(String firstName, String lastName, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}

	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Person)
		{
			Person p = (Person) obj;
			
			if(p.firstName.equalsIgnoreCase(this.firstName) 
			&& p.lastName.equalsIgnoreCase(this.lastName)
			&& p.age == this.age)
			{
				return true;
			}
				
		}
		
		return false;
	}
	
	@Override
	public String toString() {
		
		//thread-safe
		StringBuffer s = new StringBuffer(this.firstName);
		
		s.append(" ");
		s.append(this.lastName); 
		s.append(" ");
		s.append(this.age);
		s.append(" yo");
		
		return s.toString();
	}

	@Override
	public int compareTo(Person p) {
		
		int result = this.age - p.age;
		
		if(result == 0)
			result = this.lastName.compareToIgnoreCase(p.lastName);
		
		if(result == 0)
			result = this.firstName.compareToIgnoreCase(p.firstName);
		
		return result;
		
//		if(this.age > p.age)
//			return 1;
//		else if(this.age < p.age)
//			return -1;
//		else 
//			return 0;
		
	}
	
}
