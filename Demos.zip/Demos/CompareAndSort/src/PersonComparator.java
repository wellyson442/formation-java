import java.util.Comparator;

public class PersonComparator implements Comparator<Person> {

	private boolean isAscendent;
	
	public PersonComparator() {
		this(true);
	}
	
	public PersonComparator(boolean isAscendent) {
		this.isAscendent = isAscendent;
	}
	
	@Override
	public int compare(Person p1, Person p2) {
		
		int result;
		result = p1.getLastName().compareToIgnoreCase(p2.getLastName());
		
		if(result == 0)
			result = p1.getFirstName().compareToIgnoreCase(p2.getFirstName());
		
		if(result == 0)
			result = p1.getAge() - p2.getAge();
		
		if(isAscendent){
			return result;
		}
		else {
			return -result;
		}
	}

}
