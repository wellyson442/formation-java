
public class ArrayBubble {

	static void bubbleSort(Person[] persons)
	{
		boolean hasSwapped;
		Person temp;
		int scope = persons.length -1;
		
		do{
			hasSwapped = false;
			
			for (int i = 0; i < persons.length-1; i++) {
				
				int result = persons[i].compareTo(persons[i+1]);
				if(result > 0)
				{
					temp = persons[i];
					persons[i] = persons[i + 1];
					persons[i+1] = temp;
					
					hasSwapped = true;
				}
				
			}
		
		}while(hasSwapped);
		
	}
	
}
