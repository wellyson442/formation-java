import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Program {

	public static void main(String[] args) {
		
		
//		//Equals
//		Person p1 = new Person("Ted", "Mosby", 35);
//		Person p2 = new Person("ted", "mosby", 35);
//		
//		if(p1 == p2)
//			System.out.println("C'est le même objet");
//		else
//			System.out.println("Pas le même objet !");
//		
//		if(p1.equals(p2))
//			System.out.println("identique");
//		else
//			System.out.println("pas identique");
		

		//Compare
		Person ted = new Person("Ted", "Mosby", 35);
		Person lily = new Person("Lily", "Aldrin", 32);
		Person marshall = new Person("Marshall", "Eriksen", 37);
		Person barney = new Person("Barney", "Stinson", 34);
		Person robin = new Person("Robin", "Scherbatsky", 34);
		
		Person[] persons = new Person[5];
		persons[0] = ted;
		persons[1] = lily;
		persons[2] = marshall;
		persons[3] = barney;
		persons[4] = robin;
		
		for (Person person : persons) {
			System.out.println(person);
		}
		
		System.out.println("------------");
		
		
////		Comparable<Person> p = persons[0];
////		p.compareTo(persons[1]);
////		
		Arrays.sort(persons, new PersonComparator(false));
		//ArrayBubble.bubbleSort(persons);
		
		for (Person person : persons) {
			System.out.println(person);
		}
//		
//		
//		ArrayList<Person> list = new ArrayList<Person>();
//		list.add(ted);
//		list.add(lily);
//		list.add(marshall);
//		list.add(barney);
//		list.add(robin);
//		
//		for (Person person : list) {
//			System.out.println(person);
//		}
//		
//		System.out.println("------------");
//		
//		Collections.sort(list, new PersonComparator(false));
//		
//		for (Person person : list) {
//			System.out.println(person);
//		}

	}

}
