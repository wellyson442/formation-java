
public class JString {

	private char[] words;
	private int length;
	
	public JString() {
		this(0);
	}
	
	public JString(int length) {
		this.words = new char[length + 1];
		this.words[length] = '\0';
		this.length = length;
	}
	
	public JString(char[] words)
	{
		this.words = words;
		this.length = calculateLength(words);
	}
	
	private int calculateLength(char[] words) {
		
		int length = 0;
		
		while(words[length] != '\0')
			length++;
		
		return length;
	}
	
	public void concat(char[] wordsToAdd)
	{
		int wordsToAddLength = calculateLength(wordsToAdd);
		int newLength = this.length + wordsToAddLength;
		
		char[] wordsTemp = new char[newLength + 1];
		
		int i;
		for (i = 0; i < this.length; i++) {
			wordsTemp[i] = this.words[i];
		}
		
		for (int j = 0; j < wordsToAddLength; j++, i++) {
			wordsTemp[i] = wordsToAdd[j];
		}
		
		wordsTemp[newLength] = '\0';
		
		this.words = wordsTemp;
		this.length = newLength;
	}
	
	public void concat(JString stringToAdd)
	{
		int newLength = this.length + stringToAdd.getLength();
		
		char[] wordsTemp = new char[newLength + 1];
		
		int i;
		for (i = 0; i < this.length; i++) {
			wordsTemp[i] = this.words[i];
		}
		
		for (int j = 0; j < stringToAdd.getLength(); j++, i++) {
			wordsTemp[i] = stringToAdd.getWords()[j];
		}
		
		wordsTemp[newLength] = '\0';
		
		this.words = wordsTemp;
		this.length = newLength;
	}
	
	public char[] getWords() {
		return this.words;
	}
	
	public int getLength() {
		return this.length;
	}
	
	@Override
	public String toString() {
		return new String(this.words);
	}
	
	public boolean isPalindrom(){
		
	    int start = 0;
	    int end = this.length - 1;
	    
	    while (start < end)
		{
	        if (this.words[start] != words[end])
	            return false;
	       
	        start++;
	        end--;
	    }
	    
	    return true;
	}
}
