import java.util.concurrent.atomic.AtomicInteger;

public class Launch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		JString s = new JString();
//		System.out.println(s.getLength());
//		
//		s.concat(new char[]{'H', 'e', 'l', 'l', 'o', '\0'});
//		System.out.println(s.getLength());
//		s.concat(new char[]{'W', 'o', 'r', 'l', 'd', '\0'});
//		s.concat(new char[]{'B', 'y', 'e', '\0'});
//
//		System.out.println(s.getWords());
//		
		JString s2 = new JString(new char[]{'l', 'a', 'v', 'a', 'l', '\0'});
		System.out.println(s2.isPalindrom());
		//System.out.println(s2.getLength());
//		
//		s.concat(s2);
//		System.out.println(s.getWords());
		
		JString s3 = new JString(new char[]{'e', 'l', 'u', 'p', 'a', 'r', 'c', 'e', 't', 't', 'e', 'c', 'r', 'a', 'p', 'u', 'l', 'e', '\0'});
		System.out.println(s3.isPalindrom());
		//System.out.println(s3.getLength());
	
		JString s4 = new JString(new char[]{'t', 'o', 't', 't', 'o', '\0'});
		System.out.println(s4.isPalindrom());
		//System.out.println(s4.getLength());
		
		String s5 = new String("Hello");
		s5 += "world";
		s5 += "Test";
		s5 += "Bye";
		s5 += "end";
		
		StringBuilder sb2 = new StringBuilder();
		StringBuffer sb = new StringBuffer();//thread safe
		sb.append("Hello");
		sb.append("world");
		sb.append("Test");
		sb.append("bye");
		sb.append("end");
		System.out.println(sb.toString());
		
		
		int a = 5;
		a++;
		
		AtomicInteger myAtomic = new AtomicInteger(5);
		int b = myAtomic.incrementAndGet();
		
		
	}

}
