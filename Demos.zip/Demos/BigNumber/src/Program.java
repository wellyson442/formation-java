import java.math.BigDecimal;
import java.math.BigInteger;

public class Program {

	public static void main(String[] args) {
		
		bigInt();
		
		//floatCalc();
		
		//bigDec();
		
	}
	
	private static void bigInt() {
		
		long a = Long.MAX_VALUE;
		System.out.println(a);
		a++;
		System.out.println(a);
		
		Long myLong = new Long(Long.MAX_VALUE);
		String s = myLong.toString();

		BigInteger bigint = new BigInteger(s);
		bigint = bigint.add(bigint);
		bigint = bigint.multiply(bigint);
		System.out.println(bigint);
	}

	private static void floatCalc() {
		float f = 0.0f;
		
		for (int i = 0; i < 10; i++) {
			f += 0.1f;
		}
		
		for (int i = 0; i < 10; i++) {
			f -= 0.1f;
		}
		
		if (f == 0.0f)
			System.out.println("Bravo");
		else
			System.out.println("Raté");
		
		System.out.println(f);
	}

	private static void bigDec() {
		
		//norme IEEE 754
		BigDecimal decimal = new BigDecimal(0.0f);
		
		BigDecimal decimalToAdd = new BigDecimal(0.1f);
		for (int i = 0; i < 10; i++) {
			decimal.add(decimalToAdd);
		}
		for (int i = 0; i < 10; i++) {
			decimal.subtract(decimalToAdd);
		}
		
		if (decimal.floatValue() == 0.0f)
			System.out.println("Bravo");
		else
			System.out.println("Rat�");
		
		System.out.println(decimal);
		
	}

	
	
	
}
