import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Program {

	public static void main(String[] args) {
		
		//Logger logger = LogManager.getLogger(LogManager.ROOT_LOGGER_NAME);
		Logger logger = LogManager.getRootLogger();
		
		logger.debug("msg de debogage");
	    logger.info("msg d'information");
	    logger.warn("msg d'avertissement");
	    logger.error("msg d'erreur");
	    logger.fatal("msg d'erreur fatale");
	    
	}

}
